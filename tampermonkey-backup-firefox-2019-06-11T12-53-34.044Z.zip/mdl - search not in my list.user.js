// ==UserScript==
// @name         mdl - search not in my list
// @namespace    http://tampermonkey.net/
// @version      0.1
// @description  try to take over the world!
// @author       You
// @include     /^.*mydramalist\.com/search.*$/
// @include     /^.*mydramalist\.com/shows.*$/
// @include     /^.*mydramalist\.com/movies.*$/
// @grant        none
// @require      http://code.jquery.com/jquery-3.3.1.min.js
// ==/UserScript==

(function() {
    'use strict';

     /*  retVal = [   obj(){ statName , idli }, obj(){ statName , idli },  ]  */
     function Parse_watchlistHTML(html){
         var parser = new DOMParser();
         var htmlDoc = parser.parseFromString(html,"text/html");

         var tables = htmlDoc.querySelectorAll('.box');

         var watchlistByStat = [];
         for(var table of tables)
         {
             console.log(table);
             var obj = new Object();
             obj.statName= table.querySelectorAll("h3")[0].textContent.trim();
             obj.idli = [];

             var rows = table.querySelectorAll("tr");
             //console.log(rows);
             for(var row of rows)
             {
                 var btns = row.querySelectorAll(".btn");
                 if(btns == null ||  btns.length == 0 )
                     continue;

                 var id = row.querySelectorAll(".btn")[0].getAttribute("data-id");
                 obj.idli.push(id);
                 //console.log(id );

             }
             watchlistByStat.push(obj);
         }

         return watchlistByStat;
     }

     function Hide_SearchResult_ifExistinWatchlist(statName ){
         var wlByStat = JSON.parse(localStorage.watchlistByStat);

         var SearchResLi = document.querySelectorAll(".box .row");
         for (var searchRes of SearchResLi)
         {
             var btns = searchRes.querySelectorAll(".btn-manage-list");
             if(btns == null || btns.length == 0 )
                 continue;

             var btn = btns[0];
             var id = btn.getAttribute("data-id");
             for(var obj of wlByStat)
             {
                 if( obj.statName == statName )
                 {
                     var Exists = obj.idli.includes(id);
                     if(Exists)
                        searchRes.style.display = "none";
                 }

             }
         }
     }

     function Hide_SearchResult( ){

         return;
         Hide_SearchResult_ifExistinWatchlist("Completed");
         Hide_SearchResult_ifExistinWatchlist("Dropped");
         Hide_SearchResult_ifExistinWatchlist("Not Interested");
         console.log("searchRes filter -filtered");
     }



    //localStorage null
    //set null
    // localStorage.watchlistHTML = null
    // is null
    // localStorage.watchlistHTML == "null"

    //main
    console.log("searchRes filter");
    var advSearch = document.querySelectorAll("#advanced-search")[0];

    localStorage.watchlistUrl = "https://mydramalist.com/dramalist/blackholeearth0";

    if( localStorage.watchlistHTML == "null")
    {
        console.log("searchRes filter - downloading mdl");

        $.ajax({
            url : localStorage.watchlistUrl,
            success : function(result){
                //alert(result);
                console.log("searchRes filter - download success");

                localStorage.watchlistHTML = result;
                var obj = Parse_watchlistHTML(result);
                localStorage.watchlistByStat = JSON.stringify(obj);
                //console.log(obj);
                console.log("searchRes filter - parsed");

                Hide_SearchResult();
            }
        });
    }
    else
    {
        Hide_SearchResult();
    }



    function InsertGui(){

        var     wchliStats =["Completed", "On Hold" ,"Dropped" ,"Plan to Watch" ,"Not Interested"  ];
        var checkboxStrArr =[];


        for (var i = 0;  i < wchliStats.length; i++)
        {
            checkboxStrArr.push(
                newCheckBox_AsHtml(wchliStats[i],wchliStats[i] , "FilterSearchResults()")
            );
        }

        var newElem = document.createElement('span');
        newElem.innerHTML = `

<div class="box not-in-mylist" style="padding:15px">

<div style="font-weight:bold;"> Not in My xxx_List </div>
`+  checkboxStrArr.join("<br/>") +"<br/>"  +`
<br/>
<input type="textbox" name="watchlistUrl" value="https://mydramalist.com/dramalist/YourUserName" style="width: 100%;">
<input type="button" name="refreshWatchlist" value="refreshWatchlist" ></input> <br/>

</div>

`;

        var asDiv = document.querySelectorAll("#advanced-search")[0];
        asDiv.parentElement.insertBefore( newElem , asDiv);
    }

    function newCheckBox_AsHtml(id, text , onChangeFuncStr){
        return `<input type="checkbox" id="`+id+`" onchange="`+onChangeFuncStr+`" />  <label for="`+id+`" >  `+text+` </label>`;
    }

    function FilterSearchResults()
    {
        console.log("FilterSearchResults runn!!");
    }

    InsertGui();


    document.addEventListener('DOMContentLoaded', function(event) {

    });


})();