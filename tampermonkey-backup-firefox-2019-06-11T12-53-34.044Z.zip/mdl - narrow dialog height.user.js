// ==UserScript==
// @name         mdl - narrow dialog height
// @namespace    http://tampermonkey.net/
// @version      0.1
// @description  try to take over the world!
// @author       You
// @include     /^.*mydramalist\.com/.*$/
// @grant        none
// ==/UserScript==

(function() {
    'use strict';


    var styleSTR =  `
.el-dialog__header {
padding-top: 0!important;
padding-bottom: 0!important;
}

.el-dialog__body {
padding-top: 0!important;
padding-bottom: 0!important;
}

.el-dialog__footer {
padding-top: 0!important;
padding-bottom: 5px!important;
}

.el-dialog {
--margin-top: 90px !important;
}

.el-dialog__body > div:nth-of-type(1) {
    min-height: 222px!important;
}
.form-group {
    margin-bottom: 5px!important;
}
.el-dialog  hr {
   margin:5px!important;
}

`;

    var style = document.createElement('style');
    style.type = 'text/css';
    style.innerHTML = styleSTR;
    document.getElementsByTagName('head')[0].appendChild(style);
})();