// ==UserScript==
// @name         searchStyle - dmntsf
// @namespace    http://tampermonkey.net/
// @version      0.1
// @description  try to take over the world!
// @author       You
// @include        /^.*?dmntsf.net\/\?s\=.*$/
// @grant        none
// ==/UserScript==



(function() {
    'use strict';


    var styleSTR =  `

.post * {
    font-size: 22px;
    margin: 0px !important;
	padding: 0px;
}

.post {
    margin-top: 10px !important;
}

.post img {
	max-height: 200px;
}
.post > figure {
	width: 40%;
	display: inline-block;
}

.post > div {
	width: 55%;
	display: inline-block;
	margin: 0px !important;
	padding: 0px;
	vertical-align: top;
}

.site-branding {
	margin: 0px !important;
    padding: 0px!important;
    height: 50px;
    overflow:hidden;
}
`;

    var style = document.createElement('style');
    style.type = 'text/css';
    style.innerHTML = styleSTR;
    document.getElementsByTagName('head')[0].appendChild(style);
})();