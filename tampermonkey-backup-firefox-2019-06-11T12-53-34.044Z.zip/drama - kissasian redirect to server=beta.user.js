// ==UserScript==
// @name         drama - kissasian redirect to server=beta
// @namespace    http://tampermonkey.net/
// @version      0.1
// @description  kissasian  server=beta  360p select
// @author       You
// @include     /^.*kissasian\.sh/.*$/
// @grant        none
// ==/UserScript==



class ertTimer {
  constructor(funcName ,intervalms=3500, maxRunDuration=20000 , StopIfReturnsTrue=true  ) {

  	  var interval2 = setInterval(function(){
		console.log("interval - funcName:" + funcName.name);
 		try{
 			var res = funcName();

			if(StopIfReturnsTrue)
	            if(res == true)
	            	clearInterval(interval2);

 		} catch(exx){console.warn(exx.message, exx.stack);}
	}, intervalms);
	// after 15 sec delete interval
	setTimeout( function(){ clearInterval(interval2); },maxRunDuration);

    this.intervalms = intervalms;
    this.maxRunDuration = maxRunDuration;
  }

  // Getter
  get getter_intervalms() {
    return this.intervalms;
  }
  // Method
  calcRepeatTimes() {
    return this.maxRunDuration / this.intervalms;
  }
}


(function() {
    try{redirectToBeta(); } catch(exx){console.warn(exx.message, exx.stack);}
    try{select360p();     } catch(exx){console.warn(exx.message, exx.stack);}

	const et1_pressClose = new ertTimer(press_divCloseBut , 3500, 20000,true );

})();



document.addEventListener("DOMContentLoaded", function(event) {
    /**/ console.log("DOM loaded - 360p selector");

	const et1_sel360 = new ertTimer(select360p , 3500, 20000,true );

});





function press_divCloseBut()
{
	var selcss = ".divCloseBut>a";
	var divcls = document.querySelectorAll( selcss );
         console.log( "press_divCloseBut" ,divcls);

    if(divcls == null) return false;
	for (var i = 0; i < divcls.length; i++){
        divcls[i].dispatchEvent(new Event('click'));
        console.log(divcls[i]);
	}
	console.log('press_divCloseBut run.');
	return true;
}

function select360p()
{
	var sel_id = "selectQuality";
	var sel = document.querySelector( "#"+sel_id );
    if (sel == null) return false;

	for (var i = 0; i < sel.options.length; ++i){
	    if ( sel.options[i].text.indexOf("360") > -1 ){
	       sel.value = sel.options[i].value;
           sel.dispatchEvent(new Event('change'));
	       console.log(sel.options[i].text);
	       return true;
	    }
	}
	console.log('select360p run.');
	return false;
}

function redirectToBeta()
{
	var url =document.location.href;
	var regex = "/Drama/(.*?)/(Episode-(.*?)|Movie)";
	var re = new RegExp(regex);
	if (re.test(url))
	{
// 		if (
//             url.indexOf("&s=") === -1 &&
//             url.indexOf("?s=") === -1
//            )

        var regex2 = "(\\?|\\&)s=";
        var re2 = new RegExp(regex2);
        if (!re2.test(url))
		{
	       window.location.replace(url +"&s=beta"  );
		}
	}

	console.log('redirectToBeta run.');
}






