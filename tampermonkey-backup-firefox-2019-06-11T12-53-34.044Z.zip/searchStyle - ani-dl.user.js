// ==UserScript==
// @name         searchStyle - ani-dl
// @namespace    http://tampermonkey.net/
// @version      0.1
// @description  try to take over the world!
// @author       You
// @include        /^.*?anidl.org\/\/\?s\=.*$/
// @grant        none
// ==/UserScript==



(function() {
    'use strict';

    var styleSTR =  `

.container-wrapper.post-element {
    position: static !important;
    display: block;
    width: 100%;
    vertical-align: top;
    margin-top: 10px !important;
	margin-bottom: 0px !important;
}

.container-wrapper.post-element > * {
    display: inline-block !important;
    vertical-align: top;
}

.featured-area {
    width: 45%;
    border: 1px solid forestgreen;
}
.featured-area img {
    max-height:200px!important;
}

.entry-content {
    width: 51%;
    padding: 0px !important;
}

.entry-archives-header {
    padding: 0px 15px !important;
    margin: 0px !important;
    width: 100%;
}

 `;

    var style = document.createElement('style');
    style.type = 'text/css';
    style.innerHTML = styleSTR;
    document.getElementsByTagName('head')[0].appendChild(style);



})();